package Mysqldemo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Updatefun {

	public static void main(String[] args) {
		 final String URL="jdbc:mysql://localhost:3306/edubridge";
		 final String UN="root";
		 final String PASS="root";
		 Connection conn=null;
		 Statement st=null;
		 Scanner sc= new Scanner(System.in);
		 try {
	   //1. Load the Driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		//2. Make a connection
		 conn=DriverManager.getConnection(URL,UN, PASS);
		//Connection conn=DriverManager.getConnection(""jdbc:mysql://localhost/edudb:3306",""root","root");
	   //3.create a Statement 
		  st=conn.createStatement();
		  System.out.println("Enter name to update record");
			String n=sc.nextLine();
			System.out.println("Enter id");
			int id=sc.nextInt();
			String sel ="select * from mylogin where id="+id;
			ResultSet rs=st.executeQuery(sel);
if(rs.next()) {
				String upr="update mylogin set name='"+n+"' where id="+id;
				int i=st.executeUpdate(upr);
				if(i>0) {
					System.out.println("Record updated");
				}else {
					System.out.println("Record not updated");
				}
			}else {
				System.out.println(id+" not exists update not possible");
			}
		  
		 }catch(Exception e)
		 {
			 e.printStackTrace();
		 }
	



	}

}
