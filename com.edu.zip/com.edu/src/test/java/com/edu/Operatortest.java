package com.edu;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Ignore;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.After;
import org.junit.Before;

public class Operatortest {

	@Test
	public void test() {
		int a=10,b=6;
		int s=a+b;
		assertEquals(s,16);
		System.out.println("addition test case passed");
	}
		@Test
		public void concat() {
			String s="nirmala";
			String s1=" sivalingam";
			String res=s.concat(s1);
			assertEquals("nirmala sivalingam",res);
			System.out.println("comparision test case passed");
	}
		@Ignore(" not yet implemented")
		@Test
		public void test2() {
			System.out.println("test2 method");
		}
		@BeforeClass()
		public static void beforeClassMethod() {
			System.out.println("Before Class Method(connect DB)");
			//rear time connect DB
			
			
		}
		@AfterClass
		public static void afterClassMethod() {
			System.out.println("after Class Method (Disconnect DB)");
			
		}
		
		@After
		public  void afterMethod() {////after method should not be static
			System.out.println("After annotation Method (refresh webpage)");
			
		}
		@Before
		public void beforeMethod() {//before method should not be static
			System.out.println("Before annotation Method  (in web page refresh page)");
			
		}
		@Test(expected =ArithmeticException.class)
		public void testException() {
			int a=10/0;
			System.out.println("exception");
			
		}
		@Test(timeout=500)
		public void timeOut() {
			int a=0;
			System.out.println("timeout");
		}
	
		
	}


