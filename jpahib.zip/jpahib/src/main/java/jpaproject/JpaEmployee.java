package jpaproject;

public class JpaEmployee {

}
