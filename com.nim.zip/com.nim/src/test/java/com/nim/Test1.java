package com.nim;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Ignore;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.After;
import org.junit.Before;
public class Test1 {

	@Test
	public void test() {

		System.out.println("test1 method");
	}
	@Ignore(" not yet implemented")
	@Test
	public void test2() {
		System.out.println("test2 method");
	}
	@BeforeClass()
	public static void beforeClassMethod() {
		System.out.println("Before Class Method(connect DB)");
		//rear time connect DB
		
		
	}
	@AfterClass
	public static void afterClassMethod() {
		System.out.println("Before Class Method (Disconnect DB)");
		
	}
	
	@After
	public  void afterMethod() {////after method should not be static
		System.out.println("After annotation Method (refresh webpage)");
		
	}
	@Before
	public void beforeMethod() {//before method should not be static
		System.out.println("Before annotation Method  (in web page refresh page)");
		
	}
	@Test(expected =ArithmeticException.class)
	public void testException() {
		int a=10/0;
	}
	@Test(timeout=500)
	public void timeOut() {
		int a=0;
	}


	}


